import { Injectable } from '@angular/core';
import { List } from './list';
import { Observable, throwError } from 'rxjs';
import{HttpClient,HttpHeaders} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class CallService {

  constructor(private httpClient: HttpClient) { 
    console.log(httpClient);
  }
  login(data){
    return this.httpClient.post("http://localhost:3000/api/login",data); 
  }
  register(data){
    return this.httpClient.post("http://localhost:3000/api/register",data); 
  }
  search(data){
    return this.httpClient.post(`http://localhost:3000/api/list`,data); 
  }
  addurl(data){
    return this.httpClient.put(`http://localhost:3000/api/add`,data); 
  }
}
