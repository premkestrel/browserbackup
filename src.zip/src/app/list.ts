export class List{
    _id?:String;
    username:String;
    password:String;
    keyword:String;
    datas:[];
}